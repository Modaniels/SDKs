def test_smoke():
    """A minimal smoke test so pytest exits successfully in CI when no real tests exist yet."""
    assert True
