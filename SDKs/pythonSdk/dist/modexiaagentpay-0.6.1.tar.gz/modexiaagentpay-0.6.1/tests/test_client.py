import pytest
import requests_mock
from modexia import ModexiaClient
from modexia.models import PaymentReceipt, TransactionHistoryResponse
import hashlib
from datetime import datetime

# A dummy key to bypass live initialization checks
API_KEY = "mx_test_dummy_key"

@pytest.fixture
def client():
    # We set validate=False to prevent it trying to hit /user/me on __init__
    return ModexiaClient(api_key=API_KEY, validate=False)

def test_initialization(client):
    assert client.base_url == "https://sandbox.modexia.software"
    assert client.api_key == API_KEY
    assert "x-modexia-key" in client.session.headers

def test_retrieve_balance(client):
    with requests_mock.Mocker() as m:
        m.get('https://sandbox.modexia.software/api/v1/user/me', json={"data": {"balance": "10.50", "username": "agent1"}})
        balance = client.retrieve_balance()
        assert balance == "10.50"

def test_intent_based_idempotency_hash(client):
    # Use an explicit idempotency key to avoid flaky time-dependent tests
    with requests_mock.Mocker() as m:
        # Mock the transfer endpoint
        m.post('https://sandbox.modexia.software/api/v1/agent/pay', json={"success": True, "txId": "tx_mocked"})
        # Mock the wait/polling endpoint
        m.get('https://sandbox.modexia.software/api/v1/agent/transaction/tx_mocked', json={"state": "COMPLETE", "txHash": "0x123"})
        
        recipient = "0xRec"
        amount = 5.0
        explicit_key = "test_idempotency_12345"
        
        receipt = client.transfer(recipient, amount, wait=True, idempotency_key=explicit_key)
        
        # We need to look at the POST request specifically, not just last_request (which is the GET poll)
        import json
        post_request = next(r for r in m.request_history if r.method == "POST")
        payload = json.loads(post_request.text)
        
        assert payload["idempotencyKey"] == explicit_key
        assert isinstance(receipt, PaymentReceipt)
        assert receipt.success is True
        assert receipt.txHash == "0x123"

def test_get_history(client):
    with requests_mock.Mocker() as m:
        mock_response = {
            "transactions": [
                {"txId": "t1", "type": "payment", "amount": "1.0", "state": "COMPLETE", "createdAt": "2026", "providerAddress": "0x1"}
            ],
            "hasMore": False
        }
        m.get('https://sandbox.modexia.software/api/v1/user/transactions?limit=1', json=mock_response)
        
        history = client.get_history(limit=1)
        
        assert isinstance(history, TransactionHistoryResponse)
        assert len(history.transactions) == 1
        assert history.transactions[0].txId == "t1"
        assert history.hasMore is False

def test_cross_chain_transfer(client):
    with requests_mock.Mocker() as m:
        m.post('https://sandbox.modexia.software/api/v1/agent/cctp/transfer', json={"success": True, "txId": "cctp_tx_123", "status": "PENDING"})
        
        recipient = "0xCCTP"
        amount = 15.0
        to_chain = "akashnet-2"
        to_token = "0xUSDC"
        explicit_key = "test_cctp_idempotency_key"
        
        receipt = client.cross_chain_transfer(to_chain, to_token, recipient, amount, idempotency_key=explicit_key)
        
        import json
        post_request = next(r for r in m.request_history if r.method == "POST")
        payload = json.loads(post_request.text)
        
        assert payload["idempotencyKey"] == explicit_key
        assert payload["toChain"] == to_chain
        assert payload["toToken"] == to_token
        assert payload["providerAddress"] == recipient
        assert payload["amount"] == "15.0"
        
        assert isinstance(receipt, PaymentReceipt)
        assert receipt.success is True
        assert receipt.txId == "cctp_tx_123"
        assert receipt.status == "PENDING"

